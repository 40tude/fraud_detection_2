<!-- 
Compress-Archive -Path ./url.md -DestinationPath ./url.zip 
-->
Bonjour,  

* Veuillez trouver ci-dessous l'URL du projet ``fraud_detection_2``  
* Dès que je peux je vais fair un update et ajouter le lien vers la vidéo  

# Liens : 
* Projet : https://github.com/40tude/fraud_detection_2
* Vidéo : https://youtu.be/uJKpLAfofVA 

# Note :
* Prenez le temps de lire le ``README.md`` du projet
* J'y présente : 
    * l'architecture du projet et son impact sur...
    * l'organisation des fichiers et des répertoires
    * les documents importants (il y a d'autres ``README.md`` dans les sous répertoires)
    * La façon de lire les différents documents et vous incite à commencer par lire le fichier ``introduction.md``
